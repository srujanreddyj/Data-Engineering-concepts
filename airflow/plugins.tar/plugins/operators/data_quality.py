from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 conn_id ="",
                 tables=[],
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        # Map params here
        self.conn_id = conn_id
        self.tables = tables

    def execute(self, context):
        """
        Checks data quality of explicit tables on the connected DB.
        1. Test for table names in the database
        2. Test that included tables have rows
        3. Test the columns in each table for Null values 
        Params: 
          conn_id : Name of airflow connection id to a Redshift or Postgres DB
          tables : List of table names to test. 
        """
        self.log.info(f'DataQualityOperator Starting with {self.conn_id}')
        #self.log.info('DataQualityOperator not implemented yet')
        
        redshift = PostgresHook(postgres_conn_id = self.conn_id)
        self.log.info(f'tables: {self.tables}.')
        self.log.info(f'types(tables): {type(self.tables)}.')
        
        
        for table in self.tables:
            self.log.info(f'--DataQualityOperator Chcecking {table}.')
            records = redshift.get_records(
                sql=f'SELECT COUNT(*) FROM {table};')
            if len(records) < 1 or len(records[0]) < 1:
                raise ValueError(f'------Data Quality Check Failed. {table} returned no results')
            num_records = records[0][0]
            if num_records < 1:
                raise ValueError(f'------Data Quality Check Failed. {table} contained 0 rows')
                
                
        for table in self.tables:
            self.log.info(f'---Data Quality Operator Checking {table}.')
            records = redshift.get_records(
                sql = f'SELECT COUNT(*) - COUNT(-1) FROM {table};')            
            self.log.info(f'records[0][0] looks like: {records [0][0]}.')
                
            if records [0][0] > 0:
                raise ValueError(f'---Data Quality Check faied. {table} Last Column has NULL Values')
                
        self.log.info(f'------DataQualityOperator {self.conn_id} passed')        
                
                
                